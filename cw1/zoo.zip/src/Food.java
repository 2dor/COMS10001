public class Food {

    public String eaten(Animal animal) {
        return "animal eats food";
    }

    public String eaten(Dog dog) {
        return "dog eats food";
    }

    public String eaten(Cat cat) {
        return "cat eats food";
    }

}
